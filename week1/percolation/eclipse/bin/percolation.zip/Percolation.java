public class Percolation {
    private WeightedQuickUnionUF wquUF;
    private int size;
    private boolean[] openedSites;
    //private boolean[] openedSites;

    // create N-by-N grid, with all sites blocked
    public Percolation(int N)              
    {
        size = N;
        this.wquUF = new WeightedQuickUnionUF(size * size);
        openedSites = new boolean[size * size];
        for (int i = 0; i < size * size; ++i)
            openedSites[i] = false;
    }

    // open site (row i, column j) if it is not already
    public void open(int row, int column)         
    {
        checkBounds(row, column);
        int absolutePos = (size * (row - 1) + (column - 1));
        //System.out.println("open " + row + " " + column);
        openedSites[absolutePos] = true;
        lookForNeighboursConnections(row - 1, column - 1);
    }

    private void lookForNeighboursConnections(int row, int column)
    {
        int absolutePos = size * row + column;

        // top
        if (row > 0)
        {
            int topPos = absolutePos - size;
            if (topPos >= 0 && openedSites[topPos])
            {
                wquUF.union(absolutePos, topPos);
            }
        }

        // left
        if (column > 0)
        {
            int leftPos = absolutePos - 1;
            if (openedSites[leftPos])
            {
                wquUF.union(absolutePos, leftPos);
            }
        }

        // right
        if (column < (size-1))
        {
            int rightPos = absolutePos + 1;
            if (rightPos < (size * size - 1) 
                    && openedSites[rightPos])
            {
                wquUF.union(absolutePos, rightPos);
            }
        }

        //bottom
        if (row < size)
        {
            int bottomPos = absolutePos + size;
            if (bottomPos < (size * size) 
                    && openedSites[bottomPos])
                wquUF.union(absolutePos, bottomPos);
        }
    }

    // is site (row i, column j) open?
    public boolean isOpen(int i, int j)    
    {
        checkBounds(i-1, j-1);
        return openedSites[size * (i - 1) + (j - 1)];
    }
   
    private void checkBounds(int i, int j)
    {
        if (i < 0 || i > size || j < 0 || j > size) 
            throw new IndexOutOfBoundsException("out of bounds");
    }

    // is site (row i, column j) full?
    public boolean isFull(int i, int j)    
    {
        checkBounds(i-1, j-1);

        int absPos = size * (i - 1) + (j - 1);
        if (openedSites[absPos])
        {
            if (i == 1)
                return true;

            for (int topPos = 1; topPos <= size; ++topPos)
            {
                if (isOpen(1, topPos))
                {
                    if (wquUF.connected(absPos, topPos-1))
                        return true;
                }
            }
        }
        return false;
    }

    // does the system percolate?
    public boolean percolates()            
    {
        for (int tpPos = 1; tpPos <= size; ++tpPos)
        {
            if (isOpen(1, tpPos))
            {
                for (int btPos = 1; 
                        btPos <= size; ++btPos)
                {
                    int i = (size*(size-1)+(btPos-1));
                    if (isOpen(size, btPos))
                    {
                        if (wquUF.connected(i, tpPos - 1))
                            return true;
                    }
                }
            }
        }

        return false;
    }
}